// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available


// when app.view['Home'].wdg['model-1']['steps'] == app.view['Home'].wdg['model-1']['currentStep']