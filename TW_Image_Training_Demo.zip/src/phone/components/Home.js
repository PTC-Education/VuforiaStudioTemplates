// $scope, $element, $attrs, $injector, $sce, $timeout, $http, $ionicPopup, and $ionicPopover services are available

console.log($scope.app);

$scope.Snap = function() {
  console.log('hello world');
  var raw = JSON.stringify({"InputImage":$scope.view.wdg.Camera.image,
                            "InputClass":$scope.view.wdg.ImageLabel.text});
  var requestOptions = {
    method: 'POST',
    headers: {
      'appKey': 'acc07edb-8c1b-4929-add8-422a1dad64ef',
      'Content-Type': 'application/json'
    },
    body: raw
  };
  fetch("https://pp-2101111403aw.portal.ptc.io/Thingworx/Things/Skittles2/Services/AddImage", requestOptions)
    .then(response => response.text())
    .then(result => console.log(result))
    .catch(error => console.log('error', error));

}

var ImgData;

$scope.Show = function () {
  console.log('hello');	
  var myHeaders = {'appKey': 'acc07edb-8c1b-4929-add8-422a1dad64ef',
    'accept': 'application/json',
    'Content-Type':'application/json'}

    var raw = JSON.stringify({"searchExpression":$scope.view.wdg.ImageLabel.text});

    var requestOptions = {
      method: 'POST',
      headers: myHeaders,
      body: raw
    };

    fetch("https://pp-2101111403aw.portal.ptc.io/Thingworx/Things/Skittles2/Services/SearchDataTableEntries", requestOptions)
    .then(response => response.json())
    .then(function(json) {ImgData = json.rows;
                         $scope.view.wdg.ImageNumber.max = ImgData.length - 1;
                         $scope.view.wdg.ImageNumber.value = 0;
                         })
}

$scope.$watchGroup(['view.wdg.ImageNumber.value','view.wdg.ShowImages.value'],function() {
  $scope.view.wdg.Image.imgsrc = 'data:image/png;base64,'+ImgData[$scope.view.wdg.ImageNumber.value].Image;
  $scope.view.wdg.StudentName.text = "Username: "+ImgData[$scope.view.wdg.ImageNumber.value].StudentName;
  var Num = Number($scope.view.wdg.ImageNumber.value)+1;
  $scope.view.wdg.NumberOfImage.text = "Image #"+Num+" of "+ImgData.length;
  
});